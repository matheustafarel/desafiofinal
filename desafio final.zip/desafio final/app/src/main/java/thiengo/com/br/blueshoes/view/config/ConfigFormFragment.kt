package thiengo.com.br.blueshoes.view.config

import thiengo.com.br.blueshoes.view.FormFragment

abstract class ConfigFormFragment :
    FormFragment() {

    abstract fun title() : Int
}
