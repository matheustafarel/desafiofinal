package thiengo.com.br.blueshoes.domain

class Shoes(
    val model: String,
    val mainImg: String,
    val brand: Brand,
    val price: Price,
    val rate: Rate )