package thiengo.com.br.blueshoes.domain

class Brand(
    val label: String,
    val logo: String )